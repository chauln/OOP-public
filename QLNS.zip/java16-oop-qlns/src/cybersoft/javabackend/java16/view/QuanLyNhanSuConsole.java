package cybersoft.javabackend.java16.view;

import java.util.Scanner;

import cybersoft.javabackend.java16.controller.QuanLyNhanSu;
import cybersoft.javabackend.java16.model.GiamDoc;
import cybersoft.javabackend.java16.model.NhanSu;
import cybersoft.javabackend.java16.model.NhanVien;
import cybersoft.javabackend.java16.model.TruongPhong;

public class QuanLyNhanSuConsole {
	private QuanLyNhanSu controller;
	private Scanner scanner = new Scanner(System.in);
	private double loiNhuanThang = 0;
	
	public QuanLyNhanSuConsole() {
		controller = new QuanLyNhanSu();
	}
	
	public void start() {
		
		int option;
		
		do {
			inMenu();
			option = Integer.parseInt(scanner.nextLine());
		} while (xuLyMenu(option));
	}
	
	public void inMenu() {
		System.out.println("\nDanh sách chức năng:");
		System.out.println("\t1. Nhập thông tin công ty.");
		System.out.println("\t2. In thông tin công ty.");
		System.out.println("\t3. Thêm nhân sự.");
		System.out.println("\t4. Xóa nhân sự.");
		System.out.println("\t5. In danh sách nhân sự.");
		System.out.println("\t6. In tổng lương công ty.");
		System.out.println("\t7. Phân bổ nhân sự.");
		System.out.println("\t8. Tìm kiếm.");
		System.out.println("\t9. In danh sách nhân viên theo thứ tự lương giảm dần.");
		System.out.println("\t10. Danh sách thu nhập của giám đốc.");
		System.out.println("\t0. Thoát.");
		System.out.print("Lựa chọn: ");
	}
	
	public boolean xuLyMenu(int option) {
		boolean isContinue = true;
		String maNSXoa;
		
		switch (option) {
		case 1: // Nhập thông tin công ty.
			controller.nhapThongTinCongTy(scanner);
			break;
		case 2: // Xuất thông tin công ty.
			controller.xuatThongTinCongTy();
			break;
		case 3: // thêm nhân sự
			themNhanSu();
			break;
		case 4: //Xóa nhân sự: giám đốc và trưởng phòng xóa được, nhân viên chưa xóa đc - vẫn đang sửa
			System.out.print("Nhập mã nhân sự muốn xóa: ");
			maNSXoa = scanner.nextLine();
			controller.xoaNhanSu(maNSXoa);
			break;
		case 5: //In danh sách nhân sự
			controller.xuatDanhSachNhanSu();
			break;
		case 6: //In tổng lương công ty
			System.out.print("Tổng lương công ty: " + controller.tongLuongCongTy());
			break;	
		case 7: //Phân bổ nhân sự: chưa làm
			
			
			break;
		case 8: //Tìm kiếm.
			timKiem();
			break;
		case 9: //In danh sách nhân viên theo thứ tự lương giảm dần: chưa làm 
			
			break;
		case 10: //Danh sách thu nhập của giám đốc: bị sai và bị lặp record, vẫn đang code để tìm nguyên nhân
			System.out.println(String.format("%-5s%-15s%-30s%-30s","STT","Mã số","Họ tên","Thu nhập"));
			System.out.println("-----------------------------------------------------------------------");
			controller.xuatDSGiamDoc();
			break;
		case 0: 
			isContinue = false;
			break;
		default:
			System.out.println("Lựa chọn không hợp lệ.");
			break;
		}
		
		return isContinue;
	}

	private void themNhanSu() {
		System.out.println("Loại nhân viên:");
		System.out.println("1. Nhân viên");
		System.out.println("2. Trưởng phòng");
		System.out.println("3. Giám đốc");
		System.out.print("Lựa chọn: ");
		
		NhanSu nhanSu;
		
		switch (Integer.parseInt(scanner.nextLine())) {
		case 1:
			nhanSu = new NhanVien();
			break;
		case 2:
			nhanSu = new TruongPhong();
			break;
		case 3:
			nhanSu = new GiamDoc();
			break;
		default:
			System.out.println("Loại nhân sự không hợp lệ.");
			return;
		}
		
		nhanSu.nhapThongTin(scanner);
		controller.them(nhanSu);
	}
	//Tìm kiếm: mới tìm được 1 nhân sự, nếu trong trường hợp có nhiều nhân sự có cùng tiêu chí tìm kiếm thì chưa được
	private void timKiem() {
		System.out.println("------------Tìm kiếm--------------");
		System.out.println("1. Tìm nhân viên thường có lương cao nhất.");
		System.out.println("2. Tìm trưởng phòng có số lượng nhân viên dưới quyền nhiều nhất.");
		System.out.println("3. Tìm giám đốc có số lượng cổ phẩn nhiều nhất.");
		System.out.print("Lựa chọn: ");
		switch (Integer.parseInt(scanner.nextLine())) {
		case 1:
			controller.dsNhanVien();
			controller.header("nhân viên có lương cao nhất","Mã trưởng phòng");
			controller.nvLuongCaoNhat().xuatThongTin(1);
			break;
		case 2: 
			controller.dsTruongPhong();
			controller.header("trưởng phòng có nhân viên dưới quyền nhiều nhất","Số nhân viên QL");
			controller.tpNhieuNhanVien().xuatThongTin(1);
			break;
		case 3:
			controller.dsGiamDoc();
			controller.header("giám đốc có số cổ phần nhiều nhất","Số cổ phần");
			controller.gdNhieuCoPhan().xuatThongTin(1);
			break;
		default:
			System.out.println("Không có loại tìm kiếm này");
			return;
		}
			
	}
	
		
}
